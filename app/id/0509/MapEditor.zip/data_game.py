import pygame

def url_animation_of(entity):  # KHAI BÁO HÀM LẤY URL THƯ VIỆN ANIMATION KHI CHỌN VẬT THỂ
    url_path = "bin\\packages\\texture\\" + entity
    return url_path

def map_Render(type_wall,id_wall,pos_wall,tag):  # KHAI BÁO HÀM RENDER MAP
    wall_img = pygame.image.load("bin\\packages\\texture\\block\\" + type_wall +"\\"+type_wall+"_"+id_wall+".png" )
    walls = []
    for pos in pos_wall:
        x, y = pos
        wall_nc = pygame.Rect(x, y, wall_img.get_width(), wall_img.get_height())
        walls.append({"wall_image":wall_img,"wall_box":wall_nc,"wall_tag":tag})
    return walls
def animation_path_frames(urlpath, w_e, h_e, status):
    geturl = ""
    image = ""
    try:
        geturl = url_animation_of(urlpath+"\\"+status+".png")
        
        image = pygame.image.load(geturl).convert_alpha()
    except:
        geturl = url_animation_of("NULL\\"+status+".png")
        image = pygame.image.load(geturl).convert_alpha()
    frames = []  # khung hình nhập vào
    sheet_width = image.get_width()
    for i in range(sheet_width // w_e):  # vòng lặp lấy hình và add vào chuỗi
        frame = image.subsurface(pygame.Rect(i * w_e, 0, w_e, h_e))
        frames.append(frame)
    return frames



def AI_Movement(entity_idx, url_json_tag):
    print("lmao")

def bar_layer(player_entity,surface,value_health,value_exp):
    pygame.draw.rect(surface, (0,0,0,0), (0, 500, 1040, 1))
    pygame.draw.rect(surface, (255,255,255), (99, 509, 404, 22))
    pygame.draw.rect(surface, (0,0,0), (100, 510, 402, 20))
    pygame.draw.rect(surface, (0,128,0), (101, 510, int(value_health/0.05), 20))

    

class entity_lifes(): #KHAI BÁO HÀM TẠO 1 VẬT THỂ - CÓ SỰ SỐNG (CÓ THỂ DI CHUYỂN)
    def __init__(entity_id, x, y,width_e,height_e ,entity_name, pic_per_sec,speed): #KHAI HÀM GỌI NHÂN VẬT VÍ DỤ (GÁN VẬT THỂ A, CÓ TỌA ĐỘ X,Y ,CAO,RỘNG, TÊN VẬT THỂ LÀ VILLAGE) THÌ SẼ CÓ LỆNH SAU entity_lifes(A,20,20,128,128,"Village") và sẽ tạo vật thể như sau lên màn hình trò chơi
        entity_id.x = x #TỌA ĐỘ
        entity_id.y = y #TỌA ĐỘ 
        entity_id.facing = "right" 
        entity_id.vx = 0   
        entity_id.exp = 0
        entity_id.health = 20
        entity_id.stop_loopanimation = "false"
        entity_id.last_hit_time = 0  #thời gian mất máu lần trước
        entity_id.hit_delay = 100 #delay mất máu ms
        entity_id.health_max = 20
        entity_id.vy = 0
        entity_id.speed = speed    
        entity_id.animations_types = {#LẤY FRAMES / FRAME LÀ 1 TẤM HÌNH TRONG CHUỖI FRAMES NHƯNG DO NHIỀU ANINMATION KHÁC NHAU NÊN SẼ CÓ CÁC PHẦN KHÁC NHAU
 			"dungyen_right": animation_path_frames(entity_name, width_e, height_e, "dungyen_right"),
            "dungyen_left": animation_path_frames(entity_name, width_e, height_e, "dungyen_left"),
            "dibo_right": animation_path_frames(entity_name, width_e, height_e, "dibo_right"),
            "dibo_left": animation_path_frames(entity_name, width_e, height_e, "dibo_left"),
            "chay_right": animation_path_frames(entity_name, width_e, height_e, "chay_right"),
 			"chay_left": animation_path_frames(entity_name,width_e,height_e,"chay_left"),
            "chay_right": animation_path_frames(entity_name,width_e,height_e,"chay_right"),
 			"healing": animation_path_frames(entity_name,width_e,height_e,"ancomchien"),
 			"nhatdo": animation_path_frames(entity_name,width_e,height_e,"nhatdo"),
 			"die": animation_path_frames(entity_name,width_e,height_e,"die"),
 			"danhnhau_danh": animation_path_frames(entity_name,width_e,height_e,"danh"),
 			"danhnhau_ban": animation_path_frames(entity_name,width_e,height_e,"ban")
 		}
        entity_id.animation_type = "dungyen_right" #TÊN ANIMATION SẼ DIỄN RA
        entity_id.frame_offical_index = 0 #SỐ THỨ TỰ FRAME TỪ BAN ĐẦU 
        entity_id.animation_speed = pic_per_sec #TỐC ĐỘ KHUNG HÌNH CHO ANIMATION
        entity_id.offical_time = 0 #THỜI GIAN ĐÃ QUA CỦA ENTITY KHI THỰC HIỆN ANIMATION
        entity_id.frame_index = entity_id.animations_types[entity_id.animation_type] #LẤY ANIMATION TỪ FRAME ĐÃ CHỌN
        entity_id.frame_action_index = entity_id.frame_index[0] #THỰC HIỆN SẼ SỬ DỤNG ANIMATION SAU KHI ĐẴ LẤY

    def changing_animation(entity_id, name_animation): #đổi animation
        if name_animation != entity_id.animation_type:
            if name_animation in entity_id.animations_types:
                entity_id.animation_type = name_animation
                entity_id.frame_index = entity_id.animations_types[entity_id.animation_type] #animation thay đổi liên tục
                entity_id.offical_time = 0
                entity_id.frame_offical_index = 0
 			

                #BIẾN UPDATE ANIMATION THEO TĂNG DẦN CỦA entity_id.offical_time và entity_id.frame_offical_index 
    def update(entity_id, animation_time):
        if entity_id.health <= 0:
            entity_id.changing_animation("die")
            entity_id.stop_loopanimation = "true"
            if entity_id.frame_offical_index < len(entity_id.frame_index) - 1:
                entity_id.offical_time += animation_time
                if entity_id.offical_time >= entity_id.animation_speed:
                    entity_id.offical_time = 0
                    entity_id.frame_offical_index += 1
                    entity_id.frame_action_index = entity_id.frame_index[entity_id.frame_offical_index]
            return
        entity_id.offical_time += animation_time #thời gian 1 frame chạy hết khi
        if entity_id.offical_time >= entity_id.animation_speed: # so sánh thông số tốc độ khung hình , khi chạy hết khung hình trong 1 khoảng thời gian quy định như 0.1 thì sẽ tự reset lại giá trị số frame ảnh
            entity_id.offical_time = 0 #số frame ảnh reset ban đầu
            entity_id.frame_offical_index = (entity_id.frame_offical_index + 1) % len(entity_id.frame_index)
            entity_id.frame_action_index = entity_id.frame_index[entity_id.frame_offical_index]
            entity_id.offical_time += animation_time




    def draw(entity_id, surface):
        surface.blit(entity_id.frame_action_index, (entity_id.x, entity_id.y))

    def move(entity_id, keys, map_walls):
        if entity_id.stop_loopanimation == "false": 
            entity_id.vx = 0
            entity_id.vy = 0
            moving = False

            if keys[pygame.K_RIGHT]:
                entity_id.vx += entity_id.speed
                entity_id.facing = "right"
                moving = True
            if keys[pygame.K_LEFT]:
                entity_id.vx -= entity_id.speed
                entity_id.facing = "left"
                moving = True
            if keys[pygame.K_UP]:
                entity_id.vy -= entity_id.speed
                moving = True
            if keys[pygame.K_DOWN]:
                entity_id.vy += entity_id.speed
                moving = True

            # Lưu tọa độ cũ để phục hồi nếu va chạm
            old_x = entity_id.x
            old_y = entity_id.y

            # Cập nhật vị trí tạm thời
            entity_id.x += entity_id.vx
            entity_id.y += entity_id.vy

            # Tạo hitbox của nhân vật hiện tại
            hitbox_entity = pygame.Rect(entity_id.x+10, entity_id.y+7,
                                      (entity_id.frame_action_index.get_width()-20),
                                      entity_id.frame_action_index.get_height()-15)

            # Kiểm tra va chạm với từng tường
            for wall in map_walls:
                if hitbox_entity.colliderect(wall["wall_box"]): #hàm colliderect sẽ true khi hitbox [player] chạm vào [hitbox tường]
                    if wall["wall_tag"] != "none":
                        entity_id.x = old_x
                        entity_id.y = old_y
                        if wall["wall_tag"] == "poison":
                            timenow = pygame.time.get_ticks()
                            if timenow - entity_id.last_hit_time >= entity_id.hit_delay:
                                entity_id.last_hit_time = timenow
                               
                                entity_id.health = entity_id.health - 2

                        break

            # Đổi animation tự động theo hướng
            if moving:
                entity_id.changing_animation(f"dibo_{entity_id.facing}")
            else:
                entity_id.changing_animation(f"dungyen_{entity_id.facing}")
        else:
            return
            
