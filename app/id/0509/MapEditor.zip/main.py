import pygame
import data_game
import json
fps = 60
version = "1000"
value_map_default = 0
def mapchanging(value,data_maps):
    data_maping = data_maps
    print(data_maping[value])
    return data_maping[value]

def loadmap(url,valuechange):        #lấy url file map
    datarender = []

    with open(url, "r+") as file:
        map_data_value = json.load(file)
    map_value = map_data_value['value']
    map_name = map_data_value['name']
    if map_data_value['value'] != valuechange:
        map_data_value['value'] = valuechange
    print(map_data_value['value'])
        
    
    with open("bin\\packages\\map\\LuuBi&HopSocola\\"+mapchanging(map_value,map_data_value['map_value']), "r") as file:

            map_data = json.load(file)
    for block_key in map_data:
        block = map_data[block_key]
        positions = []
        for pos_key in block["pos"]:
            x = int(block["pos"][pos_key]["x"])
            y = int(block["pos"][pos_key]["y"])
            positions.append((x, y))
        wall_data = data_game.map_Render(
            block["id_url"],
            block["value"],
            positions,
            block["tag"]
        )
        datarender += wall_data
    return datarender



pygame.init()
WIDTH, HEIGHT = 1040, 560
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("LUU BEE VA NHUNG NGUOI BAN")

maprender = loadmap("bin\\packages\\map\\LuuBi&HopSocola\\map.json",0)
#maprendering


clock = pygame.time.Clock()
running = True

while running:
    
    dt = clock.tick(fps) / 1000
    screen.fill((255, 255, 255))
    for wall in maprender:
        screen.blit(wall["wall_image"], wall["wall_box"].topleft)
    keys = pygame.key.get_pressed()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
   # TEST_PLAYER.update(dt)
   # TEST_PLAYER.draw(screen)
    pygame.display.update()
    

pygame.quit()